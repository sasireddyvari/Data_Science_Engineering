% Face recoginition program
% Written by Venki on 02/11/2019
% Please keep the relevant figures in the same directory as the source code
% Output would be .jpg figures in the working directory


clear all;
close all;
clc;
AK1 = imresize( double ( rgb2gray( imread('ak1','jpg'))), [120 80]);
AK2 = imresize( double ( rgb2gray( imread('ak2','jpg'))), [120 80]);
AK3 = imresize( double ( rgb2gray( imread('ak3','jpg'))), [120 80]);
AK4 = imresize( double ( rgb2gray( imread('ak4','jpg'))), [120 80]);
AK5 = imresize( double ( rgb2gray( imread('ak5','jpg'))), [120 80]);

subplot(5,5,1), pcolor(flipud(AK1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,2), pcolor(flipud(AK2)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,3), pcolor(flipud(AK3)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,4), pcolor(flipud(AK4)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,5), pcolor(flipud(AK5)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])

KH1 = imresize( double ( rgb2gray( imread('kh1','jpg'))), [120 80]);
KH2 = imresize( double ( rgb2gray( imread('kh2','jpg'))), [120 80]);
KH3 = imresize( double ( rgb2gray( imread('kh3','jpg'))), [120 80]);
KH4 = imresize( double ( rgb2gray( imread('kh4','jpg'))), [120 80]);
KH5 = imresize( double ( rgb2gray( imread('kh5','jpg'))), [120 80]);

subplot(5,5,6), pcolor(flipud(KH1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,7), pcolor(flipud(KH2)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,8), pcolor(flipud(KH3)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,9), pcolor(flipud(KH4)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,10), pcolor(flipud(KH5)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])


AR1 = imresize( double ( rgb2gray( imread('ar1','jpg'))), [120 80]);
AR2 = imresize( double ( rgb2gray( imread('ar2','jpg'))), [120 80]);
AR3 = imresize( double ( rgb2gray( imread('ar3','jpg'))), [120 80]);
AR4 = imresize( double ( rgb2gray( imread('ar4','jpg'))), [120 80]);
AR5 = imresize( double ( rgb2gray( imread('ar5','jpg'))), [120 80]);

subplot(5,5,11), pcolor(flipud(AR1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,12), pcolor(flipud(AR2)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,13), pcolor(flipud(AR3)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,14), pcolor(flipud(AR4)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,15), pcolor(flipud(AR5)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])

VS1 = imresize( double ( rgb2gray( imread('vr1','jpg'))), [120 80]);
VS2 = imresize( double ( rgb2gray( imread('vr2','jpg'))), [120 80]);
VS3 = imresize( double ( rgb2gray( imread('vr3','jpg'))), [120 80]);
VS4 = imresize( double ( rgb2gray( imread('vr4','jpg'))), [120 80]);
VS5 = imresize( double ( rgb2gray( imread('vr5','jpg'))), [120 80]);

subplot(5,5,21), pcolor(flipud(VS1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,22), pcolor(flipud(VS2)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,23), pcolor(flipud(VS3)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,24), pcolor(flipud(VS4)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,25), pcolor(flipud(VS5)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])






VS1 = imresize( double ( rgb2gray( imread('vr1','jpg'))), [120 80]);
VS2 = imresize( double ( rgb2gray( imread('vr2','jpg'))), [120 80]);
VS3 = imresize( double ( rgb2gray( imread('vr3','jpg'))), [120 80]);
VS4 = imresize( double ( rgb2gray( imread('vr4','jpg'))), [120 80]);
VS5 = imresize( double ( rgb2gray( imread('vr5','jpg'))), [120 80]);

subplot(5,5,21), pcolor(flipud(VS1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,22), pcolor(flipud(VS2)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,23), pcolor(flipud(VS3)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,24), pcolor(flipud(VS4)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,25), pcolor(flipud(VS5)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])



RD1 = imresize( double ( rgb2gray( imread('rd1','jpg'))), [120 80]);
RD2 = imresize( double ( rgb2gray( imread('rd2','jpg'))), [120 80]);
RD3 = imresize( double ( rgb2gray( imread('rd3','jpg'))), [120 80]);
RD4 = imresize( double ( rgb2gray( imread('rd4','jpg'))), [120 80]);
RD5 = imresize( double ( rgb2gray( imread('rd5','jpg'))), [120 80]);


subplot(5,5,16), pcolor(flipud(RD1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,17), pcolor(flipud(RD2)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,18), pcolor(flipud(RD3)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,19), pcolor(flipud(RD4)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(5,5,20), pcolor(flipud(RD5)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])

print -djpeg 'All_25.jpg'


AVAK=(AK1+AK2+AK3+AK4+AK5)/5;
AVKH=(KH1+KH2+KH3+KH4+KH5)/5;
AVAR=(AR1+AR2+AR3+AR4+AR5)/5;
AVRD=(RD1+RD2+RD3+RD4+RD5)/5;
AVVS=(VS1+VS2+VS3+VS4+VS5)/5;

figure(2)
subplot(3,2,1), pcolor(flipud(AVAK)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(3,2,2), pcolor(flipud(AVKH)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(3,2,3), pcolor(flipud(AVAR)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(3,2,4), pcolor(flipud(AVRD)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(3,2,5), pcolor(flipud(AVVS)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])

print -djpeg 'Average_face.jpg'

D=[reshape(AK1,1,120*80)
   reshape(AK2,1,120*80)
   reshape(AK3,1,120*80)
   reshape(AK4,1,120*80)
   reshape(AK5,1,120*80)
   reshape(KH1,1,120*80)
   reshape(KH2,1,120*80)
   reshape(KH3,1,120*80)
   reshape(KH4,1,120*80)
   reshape(KH5,1,120*80)
   reshape(AR1,1,120*80)
   reshape(AR2,1,120*80)
   reshape(AR3,1,120*80)
   reshape(AR4,1,120*80)
   reshape(AR5,1,120*80)
   reshape(RD1,1,120*80)
   reshape(RD2,1,120*80)
   reshape(RD3,1,120*80)
   reshape(RD4,1,120*80)
   reshape(RD5,1,120*80)
   reshape(VS1,1,120*80)
   reshape(VS2,1,120*80)
   reshape(VS3,1,120*80)
   reshape(VS4,1,120*80)
   reshape(VS5,1,120*80)
   ];

A = (D')*D;
[V,D] =eigs(A,25,'lm');

figure(3)

subplot(2,3,1), face1=reshape(V(:,1),120,80);pcolor(flipud(face1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(2,3,2), face1=reshape(V(:,2),120,80);pcolor(flipud(face1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(2,3,3), face1=reshape(V(:,3),120,80);pcolor(flipud(face1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(2,3,4), face1=reshape(V(:,4),120,80);pcolor(flipud(face1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(2,3,5), face1=reshape(V(:,5),120,80);pcolor(flipud(face1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', [])
subplot(2,3,6), semilogy(diag(D),'ko','Linewidth',[3]);

print -djpeg 'Eigen_Faces.jpg'


figure(4)

vecAK = reshape(AVAK,1,120*80);
vecKH = reshape(AVKH,1,120*80);
vecAR = reshape(AVAR,1,120*80);
vecRD = reshape(AVRD,1,120*80);
vecVS = reshape(AVVS,1,120*80);

projAK = vecAK * V;
projKH = vecKH * V;
projAR = vecAR * V;
projRD = vecRD * V;
projVS = vecVS * V;


subplot(2,3,1), bar(projAK(2:25)),set(gca,'Xlim',[2 20],'Ylim',[-2000 2000],'Xtick',[],'Ytick',[]), text(12,-1700,'Kalam')
subplot(2,3,2), bar(projKH(2:25)),set(gca,'Xlim',[2 20],'Ylim',[-2000 2000],'Xtick',[],'Ytick',[]), text(12,-1700,'Kamal')
subplot(2,3,3), bar(projAR(2:25)),set(gca,'Xlim',[2 20],'Ylim',[-2000 2000],'Xtick',[],'Ytick',[]), text(12,-1700,'Aish')
subplot(2,3,4), bar(projRD(2:25)),set(gca,'Xlim',[2 20],'Ylim',[-2000 2000],'Xtick',[],'Ytick',[]), text(12,-1700,'Dravid')
subplot(2,3,5), bar(projVS(2:25)),set(gca,'Xlim',[2 20],'Ylim',[-2000 2000],'Xtick',[],'Ytick',[]), text(12,-1700,'Sehwag')

print -djpeg 'Image_Keys.jpg'


T1=imresize( double ( rgb2gray (imread('khtest','jpg'))),[120 80]); 
vec1 = reshape(T1,1,120*80);

projT1=vec1*V;

E1=norm(projT1-projAK)/norm(projAK);
E2=norm(projT1-projKH)/norm(projKH);
E3=norm(projT1-projAR)/norm(projAR);
E4=norm(projT1-projRD)/norm(projRD);
E5=norm(projT1-projVS)/norm(projVS);

E=[E1;E2;E3;E4;E5];


T2=imresize( double ( rgb2gray (imread('aktest','jpg'))),[120 80]); 
vec1 = reshape(T2,1,120*80);

projT2=vec1*V;


E6=norm(projT2-projAK)/norm(projAK);
E7=norm(projT2-projKH)/norm(projKH);
E8=norm(projT2-projAR)/norm(projAR);
E9=norm(projT2-projRD)/norm(projRD);
E10=norm(projT2-projVS)/norm(projVS);





figure;
ES=[E6;E7;E8;E9;E10];
subplot(2,3,1), pcolor(flipud(T1)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', []);
subplot(2,3,2), bar(projT1(2:25)),set(gca,'Xlim',[2 20],'Ylim',[-2000 2000],'Xtick',[],'Ytick',[]), text(12,-1700,'Kamal');
subplot(2,3,3), bar(E);
subplot(2,3,4), pcolor(flipud(T2)), shading interp, colormap(gray), set(gca,'Xtick', [],'Ytick', []);
subplot(2,3,5), bar(projT2(2:25)),set(gca,'Xlim',[2 20],'Ylim',[-2000 2000],'Xtick',[],'Ytick',[]), text(12,-1700,'Kalam');
subplot(2,3,6), bar(ES);

print -djpeg 'Face_Comparison_errors.jpg'